import React from 'react'

const StorageSettings = () => {
  return (
    <div>StorageSettings</div>
  )
}

export default StorageSettings