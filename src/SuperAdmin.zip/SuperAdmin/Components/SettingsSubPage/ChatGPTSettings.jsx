import React from 'react'

const ChatGPTSettings = () => {
  return (
    <div>ChatGPTSettings</div>
  )
}

export default ChatGPTSettings