import React from "react";

export default function EmailSettings() {
  return (
    <div className="w-full">
      {/* Title */}
      <h3 className="text-xl font-semibold mb-2 text-gray-800">
        Email Settings
      </h3>

      {/* Subtitle */}
      <p className="text-sm text-gray-500 mb-6 leading-relaxed">
        This SMTP will be used for system-level email sending. Additionally, if
        a company user does not set their SMTP, then this SMTP will be used for
        sending emails.
      </p>

      {/* Input Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-y-6 gap-x-10">
        <div>
          <label className="text-sm font-medium text-gray-700">
            Mail Driver
          </label>
          <input
            type="text"
            defaultValue="SMTP"
            className="w-full mt-1 border border-gray-300 p-2 rounded"
          />
        </div>

        <div>
          <label className="text-sm font-medium text-gray-700">Mail Host</label>
          <input
            type="text"
            placeholder="smtp.hostinger.com"
            className="w-full mt-1 border border-gray-300 p-2 rounded"
          />
        </div>

        <div>
          <label className="text-sm font-medium text-gray-700">Mail Port</label>
          <input
            type="text"
            placeholder="465"
            className="w-full mt-1 border border-gray-300 p-2 rounded"
          />
        </div>

        <div>
          <label className="text-sm font-medium text-gray-700">
            Mail Username
          </label>
          <input
            type="text"
            placeholder="admin@example.com"
            className="w-full mt-1 border border-gray-300 p-2 rounded"
          />
        </div>

        <div>
          <label className="text-sm font-medium text-gray-700">
            Mail Password
          </label>
          <input
            type="password"
            placeholder="••••••••"
            className="w-full mt-1 border border-gray-300 p-2 rounded"
          />
        </div>

        <div>
          <label className="text-sm font-medium text-gray-700">
            Mail Encryption
          </label>
          <input
            type="text"
            placeholder="SSL"
            className="w-full mt-1 border border-gray-300 p-2 rounded"
          />
        </div>

        <div>
          <label className="text-sm font-medium text-gray-700">
            Mail From Address
          </label>
          <input
            type="text"
            placeholder="admin@example.com"
            className="w-full mt-1 border border-gray-300 p-2 rounded"
          />
        </div>

        <div>
          <label className="text-sm font-medium text-gray-700">
            Mail From Name
          </label>
          <input
            type="text"
            placeholder="MindBoxx"
            className="w-full mt-1 border border-gray-300 p-2 rounded"
          />
        </div>
      </div>

      {/* Buttons */}
      <div className="flex gap-3 mt-8">
        <button className="bg-black text-white px-4 py-2 rounded">
          Send Test Mail
        </button>
        <button className="bg-black text-white px-4 py-2 rounded">
          Save Changes
        </button>
      </div>
    </div>
  );
}
