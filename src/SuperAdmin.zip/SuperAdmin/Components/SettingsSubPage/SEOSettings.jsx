import React from 'react'

const SEOSettings = () => {
  return (
    <div>SEOSettings</div>
  )
}

export default SEOSettings