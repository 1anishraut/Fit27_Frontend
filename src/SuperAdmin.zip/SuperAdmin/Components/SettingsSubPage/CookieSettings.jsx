import React from 'react'

const CookieSettings = () => {
  return (
    <div>CookieSettings</div>
  )
}

export default CookieSettings