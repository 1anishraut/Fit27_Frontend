import React from 'react'

const CacheSettings = () => {
  return (
    <div>CacheSettings</div>
  )
}

export default CacheSettings