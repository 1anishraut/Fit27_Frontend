import React from 'react'

const BrandSettings = () => {
  return (
    <div>BrandSettings</div>
  )
}

export default BrandSettings