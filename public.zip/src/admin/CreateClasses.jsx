import React from 'react'

const CreateClasses = () => {
  return (
    <div>CreateClasses</div>
  )
}

export default CreateClasses