// export const BASE_URL =
//   location.hostname === "localhost"
//     ? "http://localhost:3000"
//     : "https://campfire-cove-resort-booking-back-e.vercel.app/";

export const BASE_URL =
  location.hostname === "localhost" ? "http://localhost:3000" : "/api";


// export const BASE_URL = "https://campfire-cove-resort-booking-back-e.vercel.app";