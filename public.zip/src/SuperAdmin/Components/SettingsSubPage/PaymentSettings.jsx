import React from 'react'

const PaymentSettings = () => {
  return (
    <div>PaymentSettings</div>
  )
}

export default PaymentSettings