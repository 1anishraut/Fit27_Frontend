import React from 'react'

const PusherSettings = () => {
  return (
    <div>PusherSettings</div>
  )
}

export default PusherSettings