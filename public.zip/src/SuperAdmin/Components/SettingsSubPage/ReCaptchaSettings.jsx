import React from 'react'

const ReCaptchaSettings = () => {
  return (
    <div>ReCaptchaSettings</div>
  )
}

export default ReCaptchaSettings